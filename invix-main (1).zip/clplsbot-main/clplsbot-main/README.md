# PYRO BOT

# Deploy on heroku


<a href="https://heroku.com/deploy?template=https://github.com/Hesterdemsonhook/clplsbot">
     <img height="30px" src="https://img.shields.io/badge/Deploy%20To%20Heroku-blueviolet?style=for-the-badge&logo=heroku">
  </a>

### .env
`sh
    API_ID=12345 # Get from https://my.telegram.org/apps
    API_HASH=abcdef # Get from https://my.telegram.org/apps
    BOT_TOKEN=123:abc # Get from https://t.me/BotFather
    AUTH_USERS=123,456 # User ids of those who can use bot anywhere without limit
    GROUPS=123,456 # Chat ids where you wan't many to use the bot














